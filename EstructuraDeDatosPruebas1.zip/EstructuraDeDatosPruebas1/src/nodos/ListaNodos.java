package nodos;
import java.util.Scanner;
 class ListaNodos {
    
    int dato;
   
    ListaNodos siguiente;
    
    public ListaNodos(int dato){
        
        this.dato=dato;
        this.siguiente=null;
    }
        public static void main(String[] args) {
            ListaNodos cabeza =null;
            ListaNodos cola=null;
            
            int valor;
            int vn;
            Scanner n =new Scanner(System.in);
            System.out.print("Ingrese el numero de nodos: ");
            valor=n.nextInt();
            
            for (int i=0;i<valor;i++) {
                System.out.println("Ingrese el valor del nodo:");
                vn=n.nextInt();
                ListaNodos numero=new ListaNodos(vn);
                if (cabeza==null) {
                    cabeza=numero;
                    cola=numero;
                }else{
                    cola.siguiente=numero;
                    cola=numero;
                }
 
                
            }
            System.out.println("Lista de datos:");
            
            ListaNodos actual=cabeza;
            while(actual !=null){
                System.out.println(actual.dato);
                actual=actual.siguiente;
                
                
            }
            System.out.println("    ");

      
        }
}
