package apuntadores;
public class ArreglosReferencias {

    static class Persona {
        
        String nombre;

        Persona(String nombre) {
            this.nombre = nombre;
        }
    }
    public static void cambiarNombre(Persona[] personas, int indice, String nuevoNombre) {
        if (indice >= 0 && indice < personas.length) {
            personas[indice].nombre = nuevoNombre;
        } else {
            System.out.println("Índice fuera de rango");
        }
    }

    public static void main(String[] args) {  
        Persona[] grupo = {
            new Persona("Ana"),
            new Persona("Luis"),
            new Persona("Carlos")
        };
        
        System.out.println("Nombres originales:");
        for (Persona p : grupo) {
            System.out.println(p.nombre);
        }
        cambiarNombre(grupo, 1, "Mario");
        
        System.out.println("\nNombres despues del cambio:");
        for (Persona p : grupo) {
            System.out.println(p.nombre);
        }
    }
}
