package apuntadores;

public class TamañoArreglo {
     
    public static int[] redimensionar(int[] arreglo, int nuevoTamano) {
        int[] nuevoArreglo = new int[nuevoTamano];

        for (int i = 0; i < arreglo.length && i < nuevoTamano; i++) {
            nuevoArreglo[i] = arreglo[i];
        }

        return nuevoArreglo;
    }

    public static void main(String[] args) {
        int[] numeros = {1, 2, 3, 4};

        System.out.print("Arreglo original: ");
        for (int num : numeros) {
            System.out.print(num + " ");
        }
        System.out.println();

        int[] numerosRedimensionados = redimensionar(numeros, numeros.length * 2);

        System.out.print("Arreglo redimensionado: ");
        for (int num : numerosRedimensionados) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
