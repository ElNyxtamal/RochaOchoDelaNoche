package apuntadores;

public class IntercambioValores {
        
 
    public static void intercambiar(int[] arr) {
        int temp = arr[0];
        arr[0] = arr[1];   
        arr[1] = temp;     
    }

    public static void main(String[] args) {
        int[] numeros = {5, 10}; 

        System.out.println("Antes del intercambio:");
        System.out.println("Numero 1: " + numeros[0]);
        System.out.println("Numero 2: " + numeros[1]);

        intercambiar(numeros); 

        System.out.println("Despues del intercambio:");
        System.out.println("Numero 1: " + numeros[0]);
        System.out.println("Numero 2: " + numeros[1]);
    }
}
