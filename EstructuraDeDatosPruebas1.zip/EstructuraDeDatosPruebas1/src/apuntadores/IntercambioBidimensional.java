package apuntadores;

public class IntercambioBidimensional {
    
    public static void intercambiarFilas(int[][] matriz, int fila1, int fila2) {
        if (fila1 >= 0 && fila1 < matriz.length && fila2 >= 0 && fila2 < matriz.length) {
            int[] temp = matriz[fila1]; 
            matriz[fila1] = matriz[fila2]; 
            matriz[fila2] = temp; 
        } else {
            System.out.println("Índices de fila fuera de rango");
        }
    }
    public static void imprimirMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        
        int[][] matriz = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        System.out.println("Matriz original:");
        imprimirMatriz(matriz);

        intercambiarFilas(matriz, 0, 2);

        System.out.println("\nMatriz despues del intercambio de filas:");
        imprimirMatriz(matriz);
    }
}
