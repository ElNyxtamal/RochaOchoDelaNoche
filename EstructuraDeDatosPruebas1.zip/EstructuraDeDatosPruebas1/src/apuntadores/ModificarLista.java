package apuntadores;

public class ModificarLista {
    static class Libro {
        String titulo;
        Libro(String titulo) { this.titulo = titulo; }
    }

    public static void modificarTitulo(Libro[] lista, int indice, String nuevoTitulo) {
        if (indice >= 0 && indice < lista.length) {
            lista[indice].titulo = nuevoTitulo;
        }
    }

    public static void main(String[] args) {
        Libro[] biblioteca = {
            new Libro("Cien Anios de Soledad"),
            new Libro("Don Quijote"),
            new Libro("La Odisea")
        };

 
        for (Libro l : biblioteca) {
            System.out.println(l.titulo);
        }

        modificarTitulo(biblioteca, 1, "El Ingenioso Hidalgo Don Quijote");


        for (Libro l : biblioteca) {
            System.out.println(l.titulo);
        }
    }
}
