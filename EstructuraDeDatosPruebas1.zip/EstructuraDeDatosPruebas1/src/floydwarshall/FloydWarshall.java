package floydwarshall;

public class FloydWarshall {

    final static int INF = 99999; // Valor que representa el infinito (sin conexión)

    public static void floydWarshall(int[][] graph) {
        int n = graph.length;
        int[][] dist = new int[n][n];

        // Inicializamos la matriz de distancias con los valores del grafo original
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                dist[i][j] = graph[i][j];
            }
        }

        // Algoritmo de Floyd–Warshall
        for (int k = 0; k < n; k++) {        // k = vértice intermedio
            for (int i = 0; i < n; i++) {    // i = vértice de inicio
                for (int j = 0; j < n; j++) { // j = vértice de destino
                    if (dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                    }
                }
            }
        }

        // Imprimir la matriz de distancias finales
        printSolution(dist);
    }

    public static void printSolution(int[][] dist) {
        int n = dist.length;
        System.out.println("Matriz de distancias más cortas entre cada par de vértices:");
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (dist[i][j] == INF)
                    System.out.print("INF ");
                else
                    System.out.print(dist[i][j] + "   ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        // Ejemplo: grafo con 4 vértices
        int[][] graph = {
            {0,   5,   INF, 10},
            {INF, 0,   3,   INF},
            {INF, INF, 0,   1},
            {INF, INF, INF, 0}
        };

        floydWarshall(graph);
    }
}

