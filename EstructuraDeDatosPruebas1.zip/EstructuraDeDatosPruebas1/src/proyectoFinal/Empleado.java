package proyectoFinal;

public class Empleado {
    private String idEmpleado;
    private String Nombre;
    private String Apellido;
    private String Puesto;
    
    public Empleado (String idempleado,String nombre,String apellido,String puesto){
        this.idEmpleado=idempleado;
        this.Nombre=nombre;
        this.Apellido=apellido;
        this.Puesto=puesto;
    }
    
    public Empleado(){
    
}
    public String getIdEmpleado(){
        return idEmpleado;
    }
    public void setIdEmpleado(String idempleado){
        this.idEmpleado=idempleado;
    }
    public String getNombre(){
        return Nombre;
    }
    public void setNombre(String nombre){
        this.Nombre=nombre;
    }
    public String getApellido(){
        return Apellido;
    }
    public void setApellido(String apellido){
        this.Apellido=apellido;
    }
    public String getPuesto(){
        return Puesto;
    }
    public void setPuesto(String puesto){
        this.Puesto=puesto;
    }
}
