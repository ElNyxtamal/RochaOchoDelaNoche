package cProyectoMisterioso;

import java.util.Date;
import java.text.SimpleDateFormat;
public class ClaseTarea implements Comparable<ClaseTarea> {
    private String idTarea;
    private String nomMat;
    private String desc;
    private Date fechaEntrega;
    private boolean completo;
    private int dificultad;
    private int valor;
    
    private static final SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

    public ClaseTarea(String idTarea, String nomMat, String desc, Date fechaEntrega, boolean completo, int dificultad, int valor) {
        this.idTarea = idTarea;
        this.nomMat = nomMat;
        this.desc = desc;
        this.fechaEntrega = fechaEntrega;
        this.completo = completo;
        this.dificultad = dificultad;
        this.valor = valor;
    }

    public ClaseTarea() {
    }

    public String getIdTarea() {
        return idTarea;
    }

    public void setIdTarea(String idTarea) {
        this.idTarea = idTarea;
    }

    public String getNomMat() {
        return nomMat;
    }

    public void setNomMat(String nomMat) {
        this.nomMat = nomMat;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public boolean isCompleto() {
        return completo;
    }

    public void setCompleto(boolean completo) {
        this.completo = completo;
    }

    public int getDificultad() {
        return dificultad;
    }

    public void setDificultad(int dificultad) {
        this.dificultad = dificultad;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
    
    public String toCSV() {
        // We convert the Boolean to text and the Date to a String
        String dateStr = formato.format(fechaEntrega);
        String estado;
        if(completo == false){
            estado = "Incompleta";
        }
        else{
            estado = "Entregada";
        }
        return idTarea + "," + nomMat + "," + desc + "," + dateStr + "," + estado + "," + dificultad + "," + valor;
    }
    
    //la interfaz comparable se usa para comparar y acomodar
    //Los datos de las fechas de entrega para darle mayor
    //prioridad a la de la fecha mas cercana
    @Override
    public int compareTo(ClaseTarea otraTarea) {
        if(this.fechaEntrega == null || otraTarea.getFechaEntrega() == null){
            return 0;
        }
        return this.fechaEntrega.compareTo(otraTarea.getFechaEntrega());
    }
    
}
