package cProyectoMisterioso;

import java.util.LinkedList;

public class ClaseMateria {
    private String idMateria;
    private String nombre;
    private String maestro;
    private int creditos;
    private int inasistencias;
    //Las listas enlazadas (hijos) que tiene esta clase
    public LinkedList<ClaseTarea> listaTareas;
    public LinkedList<ClaseEvento> listaEventos;
    public LinkedList<ClaseCalificacion> listaCalificaciones;
    
    //Constructores
    public ClaseMateria(String idMateria, String nombre, String maestro, int creditos, int inasistencias) {
        this.idMateria = idMateria;
        this.nombre = nombre;
        this.maestro = maestro;
        this.creditos = creditos;
        this.inasistencias = inasistencias;
        this.listaTareas = new LinkedList<>();
        this.listaEventos = new LinkedList<>();
        this.listaCalificaciones = new LinkedList<>();
    }
    public ClaseMateria() {
        this.listaTareas = new LinkedList<>();
        this.listaEventos = new LinkedList<>();
        this.listaCalificaciones = new LinkedList<>();
    }
    //Metodo para guardar al CSV mas agilmente
    public String toCSV() {
        return idMateria + "," + nombre + "," + maestro + "," + creditos + "," + inasistencias;
    }
    @Override //Un metodo override para ayudar en los ComboBox, que se vea bonito y limpio
    public String toString() {
        return idMateria + " - " + nombre;
    }
    //Metodos Getter and Setter
    public String getIdMateria() {
        return idMateria;
    }

    public void setIdMateria(String idMateria) {
        this.idMateria = idMateria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMaestro() {
        return maestro;
    }

    public void setMaestro(String maestro) {
        this.maestro = maestro;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    public int getInasistencias() {
        return inasistencias;
    }

    public void setInasistencias(int inasistencias) {
        this.inasistencias = inasistencias;
    }
    
    
}
