/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cProyectoMisterioso;

/**
 *
 * @author Alex
 */
public class MultiLineCellRenderer extends javax.swing.JTextArea implements javax.swing.table.TableCellRenderer {

    public MultiLineCellRenderer() {
        setLineWrap(true);       // Activar salto de línea
        setWrapStyleWord(true);  // No cortar palabras a la mitad
        setOpaque(true);         // Para que se vea el color de fondo
    }

    @Override
    public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {
        
        setText((value == null) ? "" : value.toString());
        
        // Mantener los colores de selección de la tabla original
        if (isSelected) {
            setForeground(table.getSelectionForeground());
            setBackground(table.getSelectionBackground());
        } else {
            setForeground(table.getForeground());
            setBackground(table.getBackground());
        }
        
        // Ajustar la altura automáticamente
        setSize(table.getColumnModel().getColumn(column).getWidth(), getPreferredSize().height);
        
        return this;
    }
}
