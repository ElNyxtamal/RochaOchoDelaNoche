/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cProyectoMisterioso;

/**
 *
 * @author Alex
 */
public class ClaseCalificacion implements Comparable<ClaseCalificacion> {

    private String idCalificacion;
    private String nomMat; // The Link to Materia
    private String descripcion;
    private float calificacion; // The Grade (e.g. 9.5)
    private double ponderacion; // The Weight (e.g. 30%)

    public ClaseCalificacion(String idCalificacion, String nomMat, String descripcion, float calificacion, double ponderacion) {
        this.idCalificacion = idCalificacion;
        this.nomMat = nomMat;
        this.descripcion = descripcion;
        this.calificacion = calificacion;
        this.ponderacion = ponderacion;
    }

    // Helper del CSV
    public String toCSV() {
        return idCalificacion + "," + nomMat + "," + descripcion + "," + calificacion + "," + ponderacion;
    }

    @Override
    public int compareTo(ClaseCalificacion o) {
        // Compare doubles safely
        return Double.compare(o.getPonderacion(), this.ponderacion);
    }

    // Getters and Setters
    public String getIdCalificacion() {
        return idCalificacion;
    }

    public void setIdCalificacion(String idCalificacion) {
        this.idCalificacion = idCalificacion;
    }

    public String getNomMat() {
        return nomMat;
    }

    public void setNomMat(String nomMat) {
        this.nomMat = nomMat;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(float calificacion) {
        this.calificacion = calificacion;
    }

    public double getPonderacion() {
        return ponderacion;
    }

    public void setPonderacion(double ponderacion) {
        this.ponderacion = ponderacion;
    }
}
