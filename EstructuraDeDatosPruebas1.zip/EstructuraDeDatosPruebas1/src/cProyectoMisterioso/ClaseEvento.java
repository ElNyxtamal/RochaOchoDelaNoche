package cProyectoMisterioso;

import java.util.Date;
import java.text.SimpleDateFormat;
public class ClaseEvento implements Comparable<ClaseEvento>{
    private String idEvento;
    private String nomMat;
    private String evento;
    private Date fechaEvento;
    private String desc;
    private int importancia;
    private static final SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

    public ClaseEvento(String idEvento, String nomMat, String evento, Date fechaEntrega, String desc, int importancia) {
        this.idEvento = idEvento;
        this.nomMat = nomMat;
        this.evento = evento;
        this.fechaEvento = fechaEntrega;
        this.desc = desc;
        this.importancia = importancia;
    }

    public ClaseEvento() {
    }

    public String getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(String idEvento) {
        this.idEvento = idEvento;
    }

    public String getNomMat() {
        return nomMat;
    }

    public void setNomMat(String nomMat) {
        this.nomMat = nomMat;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public Date getFechaEvento() {
        return fechaEvento;
    }

    public void setFechaEvento(Date fechaEvento) {
        this.fechaEvento = fechaEvento;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getImportancia() {
        return importancia;
    }

    public void setImportancia(int importancia) {
        this.importancia = importancia;
    }
    
    public String toCSV() {
        // We convert the Boolean to text and the Date to a String
        String dateStr = formato.format(fechaEvento);
        return idEvento + "," + nomMat + "," + evento + "," + dateStr + "," + desc + "," + importancia;
    }
    
    //la interfaz comparable se usa para comparar y acomodar
    //Los datos de las fechas de entrega para darle mayor
    //prioridad a la de la fecha mas cercana
    @Override
    public int compareTo(ClaseEvento otroEvento) {
        if(this.fechaEvento == null || otroEvento.getFechaEvento() == null){
            return 0;
        }
        return this.fechaEvento.compareTo(otroEvento.getFechaEvento());
    }
}
