package estructuradedatospruebas;

public class BuscarNegativo {
    public static void main(String[] args) {
        int filas = 6;
        int columnas = 8;

        
        int[][] matriz = {
            {  5,  3,  7,  1,  2,  4,  6,  8 },
            { 10, 15, 12, 11,  9,  7, 14, 13 },
            { 20, 18, 16, -7, 22, 25, 19, 21 },
            { 30, 28, 35, 31, 29, 33, 36, 32 },
            { 40, 42, 38, 39, 41, 44, 43, 45 },
            { 50, 48, 46, 47, 49, 52, 51, 53 }
        };

        
        boolean encontrado = false;
        int filaNeg = -1, colNeg = -1;

        for (int i = 0; i < filas && !encontrado; i++) {
            for (int j = 0; j < columnas; j++) {
                if (matriz[i][j] < 0) {
                    filaNeg = i;
                    colNeg = j;
                    encontrado = true;
                   
                }
            }
        }

        
        if (encontrado) {
            System.out.println("El primer elemento negativo se encuentra en:");
            System.out.println("Fila: " + filaNeg + "  Columna: " + colNeg);
            System.out.println("Valor: " + matriz[filaNeg][colNeg]);
        } else {
            System.out.println("No se encontro ningun elemento negativo.");
        }
    }
}
