package estructuradedatospruebas;

import java.util.Scanner;

public class ValorArreglo {
    public static void main(String[] args) {
        
        int num[]={1,2,3,4,5,6,7,8,9,10};
        
       int op;
        
        Scanner opcion=new Scanner(System.in);
        
        System.out.println("Que numero quieres buscar en el arreglo?");
        op=opcion.nextInt();
        
        
        
        for (int n=0;n<10;n++) {
          if(num[n] != op){
              
          }else{
              System.out.println(op);
          }
          
            
        }
        
        
    }
}
