package estructuradedatospruebas;
import java.util.Scanner;
public class NunValor {
    
    public static void main(String[] args) {
        int num[]={1,2,2,5,8,8,6,1,1};
        
        int op;
        int con=0;
        
        System.out.println("Ingresa el numero que quieres ver cuantas veces aparece");
        Scanner opcion=new Scanner(System.in);
        op=opcion.nextInt();
        for (int n=0;n<9;n++) {
            if(op==num[n]){
                con=con+1;
            }
        }
        System.out.println("El numero "+op+" aparecio "+con+" veces");
    }
    
}
