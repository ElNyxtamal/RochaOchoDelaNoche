package estructuradedatospruebas;
import java.util.Scanner;
public class MatrizCalcular {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int filas = 15;
        int columnas = 12;
        int[][] matriz = new int[filas][columnas];

        System.out.println("Ingrese los elementos de la matriz (15x12):");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = sc.nextInt();
            }
        }

        int menor = matriz[0][0]; 
        int sumaPrimeras5 = 0;
        int negativosCol5a9 = 0;

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                int valor = matriz[i][j];

                if (valor < menor) {
                    menor = valor;
                }

                if (i < 5) {
                    sumaPrimeras5 += valor;
                }

                if (j >= 4 && j <= 8 && valor < 0) {
                    negativosCol5a9++;
                }
            }
        }

        System.out.println("\nResultados:");
        System.out.println("Menor elemento del arreglo: " + menor);
        System.out.println("Suma de los elementos de las 5 primeras filas: " + sumaPrimeras5);
        System.out.println("Cantidad de elementos negativos en columnas 5 a 9: " + negativosCol5a9);

    }
}
