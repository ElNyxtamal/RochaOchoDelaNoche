package estructuradedatospruebas;
import java.util.Random;
public class MultidimensionalAleatorios {
    public static void main(String[] args) {
        int capas = 2;
        int filas = 2;
        int columnas = 2;
        int[][][] arreglo = new int[capas][filas][columnas];
        Random rand = new Random();

        System.out.println("--- Arreglo original ---");
        for (int c = 0; c < capas; c++) {
            System.out.println("Capa " + c + ":");
            for (int i = 0; i < filas; i++) {
                for (int j = 0; j < columnas; j++) {
                    arreglo[c][i][j] = rand.nextInt(100);
                    System.out.print(arreglo[c][i][j] + "\t");
                }
                System.out.println();
            }
            System.out.println();
        }
        int[][] temp = arreglo[0];
        arreglo[0] = arreglo[1];
        arreglo[1] = temp;

        System.out.println("--- Arreglo despues de intercambiar capas ---");
        for (int c = 0; c < capas; c++) {
            System.out.println("Capa " + c + ":");
            for (int i = 0; i < filas; i++) {
                for (int j = 0; j < columnas; j++) {
                    System.out.print(arreglo[c][i][j] + "\t");
                }
                System.out.println();
            }
            System.out.println();
        }
    }
}
