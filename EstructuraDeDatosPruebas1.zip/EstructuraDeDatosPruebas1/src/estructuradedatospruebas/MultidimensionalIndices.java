package estructuradedatospruebas;

public class MultidimensionalIndices {
    public static void main(String[] args) {
        int tam = 3;
        int[][][] arreglo = new int[tam][tam][tam];

      
        for (int i = 0; i < tam; i++) {
            for (int j = 0; j < tam; j++) {
                for (int k = 0; k < tam; k++) {
                    arreglo[i][j][k] = i*i + j*j + k*k; 
                }
            }
        }

        
        System.out.println("--- Elementos del arreglo 3D con sus indices ---");
        for (int i = 0; i < tam; i++) {
            for (int j = 0; j < tam; j++) {
                for (int k = 0; k < tam; k++) {
                    System.out.println("indice [" + i + "][" + j + "][" + k + "] = " + arreglo[i][j][k]);
                }
            }
        }
    }
}
