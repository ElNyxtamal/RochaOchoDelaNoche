package estructuradedatospruebas;

import java.util.Scanner;

public class MatrizInversa {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese de cuanto va a ser la matriz:");
        int n = sc.nextInt();

        double[][] matriz = new double[n][n];
        double[][] identidad = new double[n][n];

        
        System.out.println("Ingrese los elementos de la matriz:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matriz[i][j] = sc.nextDouble();
            }
        }


        for (int i = 0; i < n; i++) {
            identidad[i][i] = 1;
        }


        for (int i = 0; i < n; i++) {
  
            double pivote = matriz[i][i];
            if (pivote == 0) {
                System.out.println("La matriz no tiene inversa (determinante = 0).");
                return;
            }


            for (int j = 0; j < n; j++) {
                matriz[i][j] /= pivote;
                identidad[i][j] /= pivote;
            }


            for (int k = 0; k < n; k++) {
                if (k != i) {
                    double factor = matriz[k][i];
                    for (int j = 0; j < n; j++) {
                        matriz[k][j] -= factor * matriz[i][j];
                        identidad[k][j] -= factor * identidad[i][j];
                    }
                }
            }
        }


        System.out.println("La matriz inversa es:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.printf("%.3f ", identidad[i][j]);
            }
            System.out.println();
        }

        sc.close();
    }
}
