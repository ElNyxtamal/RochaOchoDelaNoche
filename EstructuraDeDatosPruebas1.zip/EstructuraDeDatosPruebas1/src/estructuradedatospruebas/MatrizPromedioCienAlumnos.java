package estructuradedatospruebas;

public class MatrizPromedioCienAlumnos {
    public static void main(String[] args) {
        int c[]={3, 7, 5, 9, 2, 9, 5, 9, 4, 3,
6, 7, 2, 8, 9, 1, 7, 3, 7, 3,
10, 2, 8, 3, 2, 9, 9, 6, 3, 7,
4, 7, 1, 6, 9, 3, 4, 3, 8, 6,
4, 7, 10, 10, 3, 2, 2, 2, 6, 10,
1, 6, 5, 10, 9, 9, 3, 3, 8, 10,
8, 1, 4, 1, 4, 10, 9, 1, 8, 2,
3, 3, 5, 5, 10, 10, 6, 3, 5, 3,
7, 2, 2, 2, 3, 9, 3, 5, 9, 1,
1, 8, 6, 9, 4, 3, 2, 1, 10, 3};
        
        float p=0;
        
        int con=0;
        
        for (int i=0;i<100;i++) {
            p=p+c[i];
        }
        
        p=p/100;
        
        for (int i=0;i<100;i++) {
            if(c[i]>=p){
                con=con+1;
            }
        }
        System.out.println("Promedio: "+p);
        
        System.out.println("Num de alumnos que pasaron el promedio: "+con);
    }
}
