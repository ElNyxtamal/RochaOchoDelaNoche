package estructuradedatospruebas;

public class MultidimensionalTemperatura {
    public static void main(String[] args) {
        double[][][] temperaturas = {
            { {20, 25}, {21, 26}, {19, 24} }, 
            { {18, 23}, {17, 22}, {19, 21} }, 
            { {25, 30}, {26, 31}, {24, 29} }};

        int ciudades = 3;
        int dias = 3;
        int momentos = 2;

        System.out.println("--- Promedio de temperaturas por ciudad ---");

        for (int c = 0; c < ciudades; c++) {
            double suma = 0;
            int contador = 0;

            for (int d = 0; d < dias; d++) {
                for (int m = 0; m < momentos; m++) {
                    suma += temperaturas[c][d][m];
                    contador++;
                }
            }

            double promedio = suma / contador;
            System.out.println("Ciudad " + (c+1) + ": " + promedio + "C");
        }
    }
}
