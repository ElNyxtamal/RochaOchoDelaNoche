package estructuradedatospruebas;
import java.util.Scanner;
public class ArregloInverso {
    public static void main(String[] args) {
        
        Scanner op=new Scanner(System.in);
        
        int num[]=new int[10];
        
        System.out.println("Numeros escritos a la inversa");
        
        for(int n=0;n<10;n++){
            System.out.println("Escriba el numero "+(n+1));
            num[n]=op.nextInt();
        }
        
        System.out.println("Los numeros al reves son: ");
        
        for(int m=9;m>=0;m--){
            System.out.println(num[m]);
        }
        
    }
}
