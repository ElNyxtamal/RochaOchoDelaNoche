package estructuradedatospruebas;

public class SumaMatrices {
    public static void main(String[] args) {
        int m1[][]={{1,2,3},{4,5,6},{7,8,9}};
        int m2[][]={{11,12,13},{14,15,16},{17,18,19}};
        
      
        
        System.out.println("Matriz 1");
        for (int i=0;i<3;i++) {
            for (int j=0;j<3;j++) {
                System.out.print("["+m1[i][j]+"]");
            }
            System.out.println("");
        }
        
        System.out.println("Matriz 2");
        for (int i=0;i<3;i++) {
            for (int j=0;j<3;j++) {
                System.out.print("["+m2[i][j]+"]");
            }
            System.out.println("");
        }
        
        System.out.println("Matriz sumatoria");
        for (int i=0;i<3;i++) {
            for (int j=0;j<3;j++) {
                System.out.print("["+(m1[i][j]+m2[i][j])+"]");
            }
            System.out.println("");
        }
    }
}
