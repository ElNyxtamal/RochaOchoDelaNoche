package estructuradedatospruebas;
import java.util.Scanner;
public class MatrizChofer {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int choferes = 5;
        int dias = 6; 

        String[] nombres = new String[choferes];
        int[][] horas = new int[choferes][dias];
        double[] sueldoHora = new double[choferes];

        
        for (int i = 0; i < choferes; i++) {
            System.out.print("\nIngrese el nombre del chofer " + (i+1) + ": ");
            nombres[i] = sc.next();

            System.out.println("Ingrese las horas trabajadas (lunes a sabado):");
            for (int j = 0; j < dias; j++) {
                System.out.print("Dia " + (j+1) + ": ");
                horas[i][j] = sc.nextInt();
            }

            System.out.print("Ingrese el sueldo por hora: ");
            sueldoHora[i] = sc.nextDouble();
        }

        System.out.println("\n--- Resultados ---");

        double totalEmpresa = 0;
        int maxHorasLunes = -1;
        String choferMaxLunes = "";

        
        for (int i = 0; i < choferes; i++) {
            int totalHoras = 0;

            for (int j = 0; j < dias; j++) {
                totalHoras += horas[i][j];
            }

            double sueldoSemanal = totalHoras * sueldoHora[i];
            totalEmpresa += sueldoSemanal;

            System.out.println("\nChofer: " + nombres[i]);
            System.out.println("Total horas semana: " + totalHoras);
            System.out.println("Sueldo semanal: $" + sueldoSemanal);

            
            if (horas[i][0] > maxHorasLunes) {
                maxHorasLunes = horas[i][0];
                choferMaxLunes = nombres[i];
            }
        }

        
        System.out.println("\nTotal a pagar por la empresa: $" + totalEmpresa);
        System.out.println("El chofer que mas trabajo el lunes fue: " + choferMaxLunes +
                           " con " + maxHorasLunes + " horas.");

        
    }
}
