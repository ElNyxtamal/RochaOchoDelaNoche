package estructuradedatospruebas;

public class MultidimensionalEstudiantesSemana {
    public static void main(String[] args) {
        
        int[][][] asistencia = {
            { {1, 0}, {1, 1}, {0, 1}, {1, 1} }, 
            { {1, 1}, {1, 0}, {1, 1}, {0, 1} }, 
            { {0, 1}, {1, 1}, {1, 0}, {1, 1} }};

        int semanas = asistencia.length;
        int estudiantes = asistencia[0].length;
        int clases = asistencia[0][0].length;

        System.out.println("--- Asistencia por semana y clase ---");

        for (int s = 0; s < semanas; s++) {
            System.out.println("Semana " + (s + 1) + ":");
            for (int c = 0; c < clases; c++) {
                int suma = 0;
                for (int e = 0; e < estudiantes; e++) {
                    suma += asistencia[s][e][c];
                }
                double porcentaje = (suma * 100.0) / estudiantes;
                System.out.println("Clase " + (c + 1) + ": " + porcentaje + "% asistencia");
            }
            System.out.println();
        }
    }
}
