package estructuradedatospruebas;


public class MaximoMinimo {
    
    public static void main(String[] args) {
      int  num[]={1,2,3,4,5,6,7,8,9,10};
      
      int maximo = num[0];
      int minimo = num[0];
      
      
      for(int n=1; n<10; n++){
          if (num[n]>maximo){
              maximo=num[n]; 
          }
          if(num[n]<minimo){
              minimo=num[n];
          }
      
      }
      

      
        System.out.println("Numero maximo: "+maximo+" Numero minimo: "+minimo);
}
}
