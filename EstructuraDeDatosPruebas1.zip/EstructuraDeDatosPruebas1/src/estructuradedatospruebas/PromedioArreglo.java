package estructuradedatospruebas;

public class PromedioArreglo {

    public static void main(String[] args) {
        
    
int num[]={1,2,3,4,5,6,7,8,9,10};
    int a=0;
    double p;
    
            for(int n=0;n<10;n++){
           
            a= a+num[n];
            
            }
            
            p=a/10;
            
            System.out.println("El promedio es: "+p);
        }
}
