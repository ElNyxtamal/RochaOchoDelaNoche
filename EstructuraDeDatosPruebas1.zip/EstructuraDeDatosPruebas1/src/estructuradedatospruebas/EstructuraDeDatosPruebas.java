
package estructuradedatospruebas;

public class EstructuraDeDatosPruebas {

    public static void main(String[] args) {
        String alumnos[]={"Angela","Alex","Everest","Juan"};
        for(int i=0; i<4; i++){
            System.out.println("Hola amig@ "+alumnos[i]);
        }
}
}