package estructuradedatospruebas;

public class MatrizNegativos {
    public static void main(String[] args) {
        
        int m[][]={{-1,-2,3,4,5,6,7,8,9,10},
                                   {1,2,-3,-4,5,6,7,8,9,10},
                                   {1,2,3,4,-5,-6,7,8,9,10},
                                   {1,2,3,4,5,6,-7,-8,9,10},
                                   {1,2,3,4,5,6,7,8,-9,-10}};
        for (int i=0;i<5;i++) {
            for (int j=0;j<10;j++) {
                if(m[i][j]<0){
                    m[i][j]=0;
                }
                System.out.print("["+m[i][j]+"]");
            }
            System.out.println("");
        }
 
    }
}
