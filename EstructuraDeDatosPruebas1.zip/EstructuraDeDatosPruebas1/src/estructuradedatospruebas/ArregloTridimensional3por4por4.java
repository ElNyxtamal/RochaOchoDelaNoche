package estructuradedatospruebas;

public class ArregloTridimensional3por4por4 {
    public static void main(String[] args) {
         int[][][] num={{{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}},
                                        {{17,18,19,20},{21,22,23,24},{25,26,27,28},{29,30,31,32}},
                                        {{33,34,35,36},{37,38,39,40},{41,42,43,44},{45,46,47,48}},
                                        {{49,50,51,52},{53,54,55,56},{57,58,59,60},{61,62,63,64}}};
         
         int n=5;
         
         System.out.println("Matriz normal");
         for (int i=0;i<3;i++) {
             for (int j=0;j<4;j++) {
                 for (int k=0;k<4;k++) {
                     System.out.print("["+num[i][j][k]+"]");
                 }System.out.println("");
             }System.out.println("");
        }
         System.out.println("Matriz multiplicada");
         int[][][]mult=new int[3][4][4];
         for (int i=0;i<3;i++){
             for (int j=0;j<4;j++){
                 for (int k=0; k<4;k++){
                     System.out.print("["+(num[i][j][k]*n)+"]");
                 }System.out.println("");
             }System.out.println("");
        }
         
    }
}
