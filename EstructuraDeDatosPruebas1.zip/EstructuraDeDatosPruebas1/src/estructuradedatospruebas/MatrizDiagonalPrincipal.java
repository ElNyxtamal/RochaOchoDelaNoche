package estructuradedatospruebas;
import java.util.Scanner;
public class MatrizDiagonalPrincipal {
    public static void main(String[] args) {
        
        int m,n;
        Scanner l=new Scanner(System.in);
        
        System.out.println("Escribe el numero de filas que quieres agregar:");
        m=l.nextInt();
        
        System.out.println("Escribe el numero de columnas que quieres agregar:");
        n=l.nextInt();
        
        int ma[][]=new int[m][n];
        
        if(m!=n){
        System.out.println("La matriz no es cuadrada");
        }else{
            for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                ma[i][j] = l.nextInt();
            
        
            }
        }
            
        }
        
        System.out.println("Matriz normal");
        for (int i = 0; i <m; i++) {
            for (int j = 0; j <n; j++) {
                System.out.print("["+ma[i][j]+"]");
            }
        }
        
        System.out.println("Diagonal de las matrices:");
        for (int i = 0; i <m; i++) {
            for (int j = 0; j <n; j++) {
                if(i==j){
                    System.out.println("["+ma[i][j]+"]");
                    System.out.print("   ");
                }
            }
        }
        
        

    }
}
