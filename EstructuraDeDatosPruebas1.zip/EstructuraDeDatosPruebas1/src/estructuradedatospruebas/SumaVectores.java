package estructuradedatospruebas;


public class SumaVectores {
    public static void main(String[] args) {
        int a[]={1,2,3,4,5};
        int b[]={6,7,8,9,10};
        int c[]=new int[5];
        for(int n=0; n<5; n++){
            
            c[n]=a[n]+b[n];
          System.out.println("Suma: "+c[n]);  
        }
       
        
    }
}
