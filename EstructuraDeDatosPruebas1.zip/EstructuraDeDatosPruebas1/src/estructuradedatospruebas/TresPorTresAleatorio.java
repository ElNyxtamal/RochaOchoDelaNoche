package estructuradedatospruebas;
import java.util.Random;
public class TresPorTresAleatorio {
    public static void main(String[] args) {
        int m[][][]=new int[3][3][3];
         int maximo =0;
      int minimo =1000000000;
        Random random=new Random();
        
        System.out.println("Matriz de numeros randoms");
        for (int i=0; i<3; i++) {
            for (int j=0;j<3;j++) {
                for (int k=0;k<3; k++) {
                    m[i][j][k]=random.nextInt(100);
                    System.out.print("["+m[i][j][k]+"]");
                    if (m[i][j][k]>maximo){
                         maximo=m[i][j][k]; 
                    }
          if(m[i][j][k]<minimo){
              minimo=m[i][j][k];
          }
                }System.out.println("");
            }System.out.println("");
        }

        
        System.out.println("Numero maximo: "+maximo+" Numero minimo: "+minimo);
    }
    
}
