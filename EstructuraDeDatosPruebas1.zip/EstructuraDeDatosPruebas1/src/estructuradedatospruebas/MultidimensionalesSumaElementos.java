package estructuradedatospruebas;
import java.util.Random;

public class MultidimensionalesSumaElementos {
    public static void main(String[] args) {
        int[][][] arreglo = {
            { {1, 2, 3}, {4, 5, 6} }, 
            { {7, 8, 9}, {10, 11, 12} } 
        };

        
        System.out.println("--- Arreglo 3D ---");
        for (int c = 0; c < arreglo.length; c++) {
            System.out.println("Capa " + c + ":");
            for (int i = 0; i < arreglo[c].length; i++) {
                for (int j = 0; j < arreglo[c][i].length; j++) {
                    System.out.print(arreglo[c][i][j] + "\t");
                }
                System.out.println();
            }
            System.out.println();
        }

        
        System.out.println("--- Suma de filas por capa ---");
        for (int c = 0; c < arreglo.length; c++) {
            System.out.println("Capa " + c + ":");
            for (int i = 0; i < arreglo[c].length; i++) {
                int sumaFila = 0;
                for (int j = 0; j < arreglo[c][i].length; j++) {
                    sumaFila += arreglo[c][i][j];
                }
                System.out.println("Suma de la fila " + i + ": " + sumaFila);
            }
            System.out.println();
        }
    }
}
