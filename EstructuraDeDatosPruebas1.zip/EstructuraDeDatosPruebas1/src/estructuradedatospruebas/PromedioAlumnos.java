package estructuradedatospruebas;

import java.util.Scanner;

public class PromedioAlumnos {
    public static void main(String[] args) {
        
        Scanner contador=new Scanner(System.in);
        
        int a;
        
        String al;
        double p;
        double suma=0;
        
        System.out.println("Seleccione la cantidad de alumnos que va a haber");
        
        a=contador.nextInt();
        
        String alumnos[]=new String[a];
         double promedio[]=new double[a];
         
         for(int n=0;n<a;n++){
             System.out.println("Ingrese nombre del alumno "+(n+1));
             Scanner nombre=new Scanner(System.in);
             alumnos[n]=nombre.nextLine();
             
             System.out.println("Ingrese promedio del alumno "+(n+1));
             
             Scanner prom=new Scanner(System.in);
             promedio[n]=prom.nextDouble();
             
             suma=suma+promedio[n];
             
         }
         
         
         System.out.println("Nombre y promedio:");
         for(int m=0;m<a;m++){
             System.out.println("Nombre: "+alumnos[m]+" Promedio: "+promedio[m]);
             
         }
         double pro=suma/a;
         System.out.println("Promedio general: "+pro);
    }
}
