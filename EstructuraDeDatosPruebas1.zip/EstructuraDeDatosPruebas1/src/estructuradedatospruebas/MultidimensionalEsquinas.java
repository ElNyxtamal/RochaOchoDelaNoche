package estructuradedatospruebas;

public class MultidimensionalEsquinas {
    public static void main(String[] args) {
        int tam = 4;
        int[][][] arreglo = new int[tam][tam][tam];

        
        int valor = 2; 
        for (int i = 0; i < tam; i++) {
            for (int j = 0; j < tam; j++) {
                for (int k = 0; k < tam; k++) {
                    arreglo[i][j][k] = valor;
                    valor += 2;
                }
            }
        }

        
        System.out.println("--- Valores en las esquinas ---");
        int[][] posicionesEsquinas = {
            {0,0,0}, {0,0,tam-1}, {0,tam-1,0}, {0,tam-1,tam-1},
            {tam-1,0,0}, {tam-1,0,tam-1}, {tam-1,tam-1,0}, {tam-1,tam-1,tam-1}
        };

        for (int[] pos : posicionesEsquinas) {
            int i = pos[0], j = pos[1], k = pos[2];
            System.out.println("Posicion [" + i + "][" + j + "][" + k + "] = " + arreglo[i][j][k]);
        }
    }
}
