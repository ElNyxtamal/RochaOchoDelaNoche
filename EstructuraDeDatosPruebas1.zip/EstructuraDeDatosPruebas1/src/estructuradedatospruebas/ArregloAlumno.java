package estructuradedatospruebas;
import java.util.Scanner;
public class ArregloAlumno {
    
    public static void main(String[] args) {
        
        Scanner leer=new Scanner(System.in);
        
        String alumnos[]={"Alex","Domingo","Everest"};
        double calif[]={6,7,8};
        System.out.println("Dane el nombre del alumno que quieres buscar");
        String busqueda=leer.next();
        for(int n=0;n<3;n++){
            if(alumnos[n].equalsIgnoreCase(busqueda)){
                System.out.println("Alumno: "+alumnos[n]);
                System.out.println("Calificacion: "+calif[n]);
        }
        }
    }
    
}
