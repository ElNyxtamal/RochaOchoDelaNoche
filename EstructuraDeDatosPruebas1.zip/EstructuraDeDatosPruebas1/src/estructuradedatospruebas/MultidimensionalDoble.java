package estructuradedatospruebas;

public class MultidimensionalDoble {
    public static void main(String[] args) {

        
        int[][][] arreglo1 = {
            { {1, 2}, {3, 4} },
            { {5, 6}, {7, 8} }
        };

        int[][][] arreglo2 = {
            { {1, 2}, {3, 4} },
            { {5, 6}, {7, 8} }
        };

        boolean iguales = true;

        
        for (int i = 0; i < arreglo1.length && iguales; i++) {
            for (int j = 0; j < arreglo1[i].length && iguales; j++) {
                for (int k = 0; k < arreglo1[i][j].length && iguales; k++) {
                    if (arreglo1[i][j][k] != arreglo2[i][j][k]) {
                        iguales = false;
                    }
                }
            }
        }

        
        if (iguales) {
            System.out.println("Los arreglos 3D son iguales.");
        } else {
            System.out.println("Los arreglos 3D son diferentes.");
        }
    }
}
