package pila;

public class AddRemove {
    private int[] cola;
    private int frente;
    private int finalCola;
    private int tamañoMaximo;
    private int tamañoActual;

    // Constructor para inicializar la cola
    public AddRemove(int tamañoMaximo) {
        this.cola = new int[tamañoMaximo];
        this.tamañoMaximo = tamañoMaximo;
        this.frente = 0;
        this.finalCola = -1;
        this.tamañoActual = 0;
    }

    // Operación enqueue: insertar un elemento al final de la cola
    public void enqueue(int elemento) {
        if (tamañoActual == tamañoMaximo) {
            System.out.println("La cola esta llena");
        } else {
            finalCola = (finalCola + 1) % tamañoMaximo;
            cola[finalCola] = elemento;
            tamañoActual++;
            System.out.println("Elemento " + elemento + " insertado");
        }
    }

    // Operación dequeue: remover el primer elemento de la cola
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("La cola esta vacía");
            return -1; // Indicador de error
        } else {
            int elemento = cola[frente];
            frente = (frente + 1) % tamañoMaximo;
            tamañoActual--;
            System.out.println("Elemento " + elemento + " removido");
            return elemento;
        }
    }

    // Operación peek: obtener el valor del primer elemento sin eliminarlo
    public int peek() {
        if (isEmpty()) {
            System.out.println("La cola esta vacia");
            return -1; // Indicador de error
        } else {
            return cola[frente];
        }
    }

    // Operación isEmpty: verificar si la cola está vacía
    public boolean isEmpty() {
        return tamañoActual == 0;
    }

    // **** ¡NUEVO MÉTODO! ****
    // Operación para imprimir todos los elementos de la cola
    public void imprimirCola() {
        if (isEmpty()) {
            System.out.println("La cola esta vacia, no hay nada que imprimir.");
            return; // Salimos del método si no hay nada que mostrar
        }

        System.out.println("--- Elementos Actuales en la Cola (Frente -> Final) ---");
        
        // Usamos un índice temporal que empieza en 'frente'
        int indiceTemporal = frente;

        // Iteramos 'tamañoActual' veces, que es el número real de elementos
        for (int i = 0; i < tamañoActual; i++) {
            
            // Imprimimos el elemento en el índice temporal
            System.out.print(cola[indiceTemporal] + " ");

            // Movemos el índice temporal al siguiente elemento,
            // usando la lógica circular
            indiceTemporal = (indiceTemporal + 1) % tamañoMaximo;
        }
        
        System.out.println("\n----------------------------------------------------"); // Salto de línea para formatear
    }


    // Método principal para probar las operaciones
    public static void main(String[] args) {
        // CORRECCIÓN: Tu clase se llama AddRemove, no Cola
        AddRemove cola = new AddRemove(10); 

        // Realizando algunas operaciones
        cola.enqueue(3);   // Insertar el valor 3
        cola.enqueue(8);   // Insertar el valor 8
        cola.enqueue(12);  // Insertar el valor 12
        cola.enqueue(20);
        cola.enqueue(5);
        cola.enqueue(15);

        // ¡Probando el nuevo método!
        cola.imprimirCola(); // Debería imprimir: 3 8 12 20 5 15

        System.out.println("\nEl valor en el frente es: " + cola.peek());  // Ver el primer elemento (3)
        
        cola.dequeue();      // Remover el primer elemento (3)
        cola.dequeue();      // Remover el primer elemento (8)
        
        // ¡Probando de nuevo después de quitar elementos!
        System.out.println("\n...Despues de dos dequeues...");
        cola.imprimirCola(); // Debería imprimir: 12 20 5 15

        System.out.println("\nEl valor en el frente es: " + cola.peek());  // Ver el nuevo primer elemento (12)

        System.out.println("La cola esta vacia?: " + cola.isEmpty());   // Verificar si la cola está vacía (false)
        
        cola.enqueue(7);
        cola.enqueue(9);
        
        // ¡Probando de nuevo después de agregar más elementos!
        System.out.println("\n...Despues de agregar 7 y 9...");
        cola.imprimirCola(); // Debería imprimir: 12 20 5 15 7 9
        
        System.out.println("\nLa cola esta vacia?: " + cola.isEmpty());
    }
}