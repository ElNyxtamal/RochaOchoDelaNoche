package pila;

public class Cola {
    private int[] cola;
    private int frente;
    private int finalCola;
    private int tamañoMaximo;
    private int tamañoActual;

    // Constructor para inicializar la cola
    public Cola(int tamañoMaximo) {
        this.cola = new int[tamañoMaximo];
        this.tamañoMaximo = tamañoMaximo;
        this.frente = 0;
        this.finalCola = -1;
        this.tamañoActual = 0;
    }

    // Operación enqueue: insertar un elemento al final de la cola
    public void enqueue(int elemento) {
        if (tamañoActual == tamañoMaximo) {
            System.out.println("La cola esta llena");
        } else {
            finalCola = (finalCola + 1) % tamañoMaximo;
            cola[finalCola] = elemento;
            tamañoActual++;
            System.out.println("Elemento " + elemento + " insertado");
        }
    }

    // Operación dequeue: remover el primer elemento de la cola
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("La cola esta vacia");
            return -1; // Indicador de error
        } else {
            int elemento = cola[frente];
            frente = (frente + 1) % tamañoMaximo;
            tamañoActual--;
            System.out.println("Elemento " + elemento + " removido");
            return elemento;
        }
    }

    // Operación peek: obtener el valor del primer elemento sin eliminarlo
    public int peek() {
        if (isEmpty()) {
            System.out.println("La cola esta vacia");
            return -1; // Indicador de error
        } else {
            return cola[frente];
        }
    }

    // Operación isEmpty: verificar si la cola está vacía
    public boolean isEmpty() {
        return tamañoActual == 0;
    }

    // Método principal para probar las operaciones
    public static void main(String[] args) {
        Cola cola = new Cola(5); // Crear una cola con tamaño máximo de 5

        // Realizando algunas operaciones
        cola.enqueue(5);   // Insertar el valor 5
        cola.enqueue(10);  // Insertar el valor 10
        cola.enqueue(15);  // Insertar el valor 15

        System.out.println("El valor en el frente es: " + cola.peek());  // Ver el primer elemento (5)
        
        cola.dequeue();     // Remover el primer elemento (5)
        System.out.println("El valor en el frente es: " + cola.peek());  // Ver el nuevo primer elemento (10)

        System.out.println("La cola esta vacia?: " + cola.isEmpty());   // Verificar si la cola está vacía (false)
        
        cola.dequeue();     // Remover el primer elemento (10)
        cola.dequeue();     // Remover el primer elemento (15)
        
        System.out.println("La cola esta vacia?: " + cola.isEmpty());   // Verificar si la cola está vacía (true)
    }
}
