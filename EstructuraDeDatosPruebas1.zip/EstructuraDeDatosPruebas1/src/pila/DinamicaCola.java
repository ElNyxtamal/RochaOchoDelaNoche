package pila;

public class DinamicaCola {

    // 1. CLASE INTERNA (NODO)
    // Esta es la "caja" que guarda el valor y la flecha al siguiente.
    private class Nodo {
        int valor;
        Nodo siguiente;

        public Nodo(int valor) {
            this.valor = valor;
            this.siguiente = null;
        }
    }

    // 2. ATRIBUTOS DE LA COLA
    // Ya no usamos un arreglo. Solo necesitamos el inicio y el fin.
    private Nodo frente;     // El primer nodo de la lista
    private Nodo finalCola;  // El último nodo de la lista

    // 3. CONSTRUCTOR
    // Inicializa la cola como vacía
    public DinamicaCola() {
        this.frente = null;
        this.finalCola = null;
    }

    // 4. OPERACIONES

    // Operación isEmpty: verificar si la cola está vacía
    public boolean isEmpty() {
        // Si 'frente' es null, la cola está vacía.
        return (frente == null);
    }

    // Operación enqueue: insertar un elemento al final de la cola
    public void enqueue(int elemento) {
        // 1. Creamos el nuevo nodo con el valor
        Nodo nuevoNodo = new Nodo(elemento);

        // 2. Verificamos si la cola está vacía
        if (isEmpty()) {
            // Si está vacía, el nuevo nodo es tanto el frente como el final
            frente = nuevoNodo;
            finalCola = nuevoNodo;
        } else {
            // Si no está vacía:
            // 3. Enganchamos el nodo actual (finalCola) con el nuevo nodo
            finalCola.siguiente = nuevoNodo;
            // 4. Actualizamos 'finalCola' para que apunte al nuevo último nodo
            finalCola = nuevoNodo;
        }
        System.out.println("Elemento " + elemento + " insertado");
    }

    // Operación dequeue: remover el primer elemento de la cola
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("La cola esta vacía");
            return -1; // Indicador de error
        } else {
            // 1. Guardamos el valor que vamos a sacar
            int elemento = frente.valor;
            
            // 2. Movemos el puntero 'frente' al siguiente nodo en la lista
            frente = frente.siguiente;

            // 3. CASO ESPECIAL: Si la cola se quedó vacía
            // Si 'frente' es null, 'finalCola' también debe ser null.
            if (frente == null) {
                finalCola = null;
            }

            System.out.println("Elemento " + elemento + " removido");
            return elemento;
        }
    }

    public int peek() {
        if (isEmpty()) {
            System.out.println("La cola esta vacía");
            return -1; // Indicador de error
        } else {
            return frente.valor;
        }
    }

    public void imprimirCola() {
        if (isEmpty()) {
            System.out.println("La cola esta vacía.");
            return;
        }

        System.out.println("\n--- Contenido Final de la Cola (Frente -> Final) ---");
        Nodo temporal = frente; 
        while (temporal != null) { 
            System.out.print(temporal.valor + " -> ");
            temporal = temporal.siguiente;
        }
        System.out.println("NULL (Fin)");
    }

    public static void main(String[] args) {
        
        DinamicaCola cola = new DinamicaCola();

        System.out.println("--- Insertando 4 elementos ---");
        cola.enqueue(5);
        cola.enqueue(10);
        cola.enqueue(15);
        cola.enqueue(20);

        System.out.println("\n--- Removiendo 1 elemento ---");
        cola.dequeue();

        System.out.println("\n--- Insertando 2 elementos mas ---");
        cola.enqueue(25);
        cola.enqueue(30);
        
        cola.imprimirCola();
    }
}
