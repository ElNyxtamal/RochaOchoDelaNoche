package pila;

public class PrioridadCola { // Usamos el nombre de tu clase
    private int[] cola;         // Arreglo para los elementos (valores)
    private int[] prioridades;  // Arreglo para las prioridades
    private int tamañoMaximo;
    private int tamañoActual;
    
    // 'frente' y 'finalCola' se eliminan, no son necesarios aquí.

    // Constructor para inicializar la cola
    public PrioridadCola(int tamañoMaximo) {
        this.tamañoMaximo = tamañoMaximo;
        this.cola = new int[tamañoMaximo];
        this.prioridades = new int[tamañoMaximo];
        this.tamañoActual = 0; // Solo necesitamos saber cuántos elementos hay
    }

    // Operación isEmpty: verificar si la cola está vacía
    public boolean isEmpty() {
        return tamañoActual == 0;
    }

    // Operación isFull: verificar si la cola está llena (método auxiliar)
    public boolean isFull() {
        return tamañoActual == tamañoMaximo;
    }

    // Operación enqueue: insertar un elemento CON su prioridad
    // (Se agrega al final del espacio usado del arreglo)
    public void enqueue(int elemento, int prioridad) {
        if (isFull()) {
            System.out.println("La cola esta llena");
        } else {
            // Agrega el elemento y su prioridad al final
            cola[tamañoActual] = elemento;
            prioridades[tamañoActual] = prioridad;
            tamañoActual++;
            System.out.println("Elemento " + elemento + " (Prioridad: " + prioridad + ") insertado");
        }
    }

    // Operación dequeue: remover el elemento con MÁS prioridad
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("La cola esta vacia");
            return -1; // Indicador de error
        }

        // 1. Encontrar el índice de la prioridad más alta
        int indicePrioridadMax = 0;
        int prioridadMax = prioridades[0];

        for (int i = 1; i < tamañoActual; i++) {
            // Si encontramos una prioridad mayor, actualizamos el índice
            if (prioridades[i] > prioridadMax) {
                prioridadMax = prioridades[i];
                indicePrioridadMax = i;
            }
        }

        // 2. Guardar el elemento que vamos a remover
        int elementoRemovido = cola[indicePrioridadMax];

        // 3. Desplazar los elementos para "eliminar" el hueco
        // Movemos todos los elementos (desde el índice que sacamos
        // hasta el final) una posición a la izquierda.
        for (int i = indicePrioridadMax; i < tamañoActual - 1; i++) {
            cola[i] = cola[i + 1];
            prioridades[i] = prioridades[i + 1];
        }

        // 4. Disminuir el tamaño actual
        tamañoActual--;

        System.out.println("-> Elemento " + elementoRemovido + " (Prioridad: " + prioridadMax + ") removido.");
        return elementoRemovido;
    }

    // Operación peek: obtener el valor del PRÓXIMO elemento en salir
    // (En este caso, el de mayor prioridad)
    public int peek() {
        if (isEmpty()) {
            System.out.println("La cola esta vacia");
            return -1; // Indicador de error
        }
        
        // 1. Encontrar el índice de la prioridad más alta (sin remover)
        int indicePrioridadMax = 0;
        int prioridadMax = prioridades[0];

        for (int i = 1; i < tamañoActual; i++) {
            if (prioridades[i] > prioridadMax) {
                prioridadMax = prioridades[i];
                indicePrioridadMax = i;
            }
        }
        
        // 2. Devolver el elemento en ese índice
        return cola[indicePrioridadMax];
    }


    // Método principal para probar las operaciones
    // (Usando los datos que me diste en la petición anterior)
    public static void main(String[] args) {
        PrioridadCola cola = new PrioridadCola(10); // Crear una cola con tamaño 10

        System.out.println("--- Insertando Elementos ---");
        // Insertando los valores (elemento, prioridad)
        cola.enqueue(15, 3);
        cola.enqueue(10, 1);
        cola.enqueue(5, 2);
        cola.enqueue(8, 2);  
        cola.enqueue(20, 4); // La prioridad más alta

        System.out.println("\nEl proximo elemento en salir (peek) es: " + cola.peek()); // Debería ser 20

        System.out.println("\n--- Removiendo Elementos por Prioridad ---");

        // Vaciamos la cola. Deberían salir en orden de prioridad.
        while (!cola.isEmpty()) {
            cola.dequeue();
        }
        
        System.out.println("\nLa cola esta vacia?: " + cola.isEmpty());
    }
}
