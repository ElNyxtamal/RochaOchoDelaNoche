package pila;

public class SistemaTurnosCola {
        private int[] cola;
        private int frente;
        private int finalCola;
        private int tamañoMaximo;
        private int tamañoActual;

        // Constructor para inicializar la cola
        public SistemaTurnosCola(int tamañoMaximo) {
            this.cola = new int[tamañoMaximo];
            this.tamañoMaximo = tamañoMaximo;
            this.frente = 0;
            this.finalCola = -1;
            this.tamañoActual = 0;
        }

        // Operación enqueue: insertar un elemento al final de la cola
        public void enqueue(int elemento) {
            if (tamañoActual == tamañoMaximo) {
                System.out.println("La cola esta llena");
            } else {
                finalCola = (finalCola + 1) % tamañoMaximo;
                cola[finalCola] = elemento;
                tamañoActual++;
                System.out.println("Elemento " + elemento + " insertado");
            }
        }

        // Operación dequeue: remover el primer elemento de la cola
        public int dequeue() {
            if (isEmpty()) {
                System.out.println("La cola esta vacia");
                return -1; // Indicador de error
            } else {
                int elemento = cola[frente];
                frente = (frente + 1) % tamañoMaximo;
                tamañoActual--;
                System.out.println("Elemento " + elemento + " removido");
                return elemento;
            }
        }

        // Operación peek: obtener el valor del primer elemento sin eliminarlo
        public int peek() {
            if (isEmpty()) {
                System.out.println("La cola esta vacía");
                return -1; // Indicador de error
            } else {
                return cola[frente];
            }
        }

        // Operación isEmpty: verificar si la cola está vacía
        public boolean isEmpty() {
            return tamañoActual == 0;
        }

        // Método principal para probar las operaciones
        public static void main(String[] args) {
            SistemaTurnosCola cola = new SistemaTurnosCola(10); // Crear una cola con tamaño máximo de 5

            // Realizando algunas operaciones
            cola.enqueue(1);   // Insertar el valor 5
            cola.enqueue(2);  // Insertar el valor 10
            cola.enqueue(3);  // Insertar el valor 15
            cola.enqueue(4);
            cola.enqueue(5);

            System.out.println("El cliente por ser atendido es: " + cola.peek());  // Ver el primer elemento (1)

            cola.dequeue();     // Remover el primer elemento (1)

            cola.enqueue(6);
            cola.enqueue(7);

            System.out.println("El cliente por ser atendido es: " + cola.peek());  // Ver el nuevo primer elemento (2)(3)
            cola.dequeue();
            cola.dequeue();

            System.out.println("El cliente por ser atendido es: " + cola.peek());  
        }
    } 

