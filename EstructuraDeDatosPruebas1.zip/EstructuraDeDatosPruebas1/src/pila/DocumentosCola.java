package pila;

public class DocumentosCola {

    private int[] cola;
    private int frente;
    private int finalCola;
    private int tamañoMaximo;
    private int tamañoActual;

    public DocumentosCola(int tamañoMaximo) {
        this.cola = new int[tamañoMaximo];
        this.tamañoMaximo = tamañoMaximo;
        this.frente = 0;
        this.finalCola = -1;
        this.tamañoActual = 0;
    }

    public boolean isEmpty() {
        return tamañoActual == 0;
    }

    public boolean isFull() {
        return tamañoActual == tamañoMaximo;
    }

    public void enqueue(int paginas) {
        if (isFull()) {
            System.out.println("Cola de impresion llena. No se pudo agregar doc de " + paginas + " pag.");
        } else {
            finalCola = (finalCola + 1) % tamañoMaximo;
            cola[finalCola] = paginas;
            tamañoActual++;
            System.out.println("Documento de " + paginas + " paginas agregado a la cola.");
        }
    }

    public int dequeue() {
        if (isEmpty()) {
            System.out.println("La cola de impresion está vacia.");
            return -1;
        } else {
            int elemento = cola[frente];
            frente = (frente + 1) % tamañoMaximo;
            tamañoActual--;
            System.out.println("-> Imprimiendo documento de " + elemento + " paginas...");
            return elemento;
        }
    }

    public int peek() {
        if (isEmpty()) {
            System.out.println("La cola de impresion esta vacia.");
            return -1;
        } else {
            return cola[frente];
        }
    }

    public void imprimirEstadoCola() {
        if (isEmpty()) {
            System.out.println("Estado de la cola: (Vacía)");
            return;
        }

        System.out.println("\n--- Estado Final de la Cola de Impresion ---");
        System.out.print("(Siguiente en Imprimir) -> ");
        
        int indiceTemporal = frente;
        for (int i = 0; i < tamañoActual; i++) {
            System.out.print("[" + cola[indiceTemporal] + " pag.] ");
            indiceTemporal = (indiceTemporal + 1) % tamañoMaximo;
        }
        System.out.println("-> (Final)");
    }

    public static void main(String[] args) {
        
        DocumentosCola impresora = new DocumentosCola(10); 
        System.out.println("--- Iniciando simulacion de impresora ---");

        impresora.enqueue(5);
        impresora.enqueue(10);
        impresora.enqueue(3);

        System.out.println("\n--- Atendiendo un trabajo ---");
        impresora.dequeue();

        System.out.println("\n--- Llegando nuevos trabajos ---");
        impresora.enqueue(7);
        impresora.enqueue(2);

        System.out.println("\n--- Revision de trabajos pendientes ---");
        System.out.println("El SIGUIENTE documento a imprimir es de: " + impresora.peek() + " paginas.");
        
        impresora.imprimirEstadoCola();
    }
}
