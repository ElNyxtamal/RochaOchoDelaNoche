package pila;

public class Pila {
    private int[] pila;
    private int top;
    private int tamanoMaximo;

    // Constructor para inicializar la pila
    public Pila(int tamanoMaximo) {
        this.pila = new int[tamanoMaximo];
        this.tamanoMaximo = tamanoMaximo;
        this.top = -1; // Indica que la pila esta vacía
    }

    // Operacion push: insertar un elemento en la pila
    public void push(int elemento) {
        if (top == tamanoMaximo - 1) {
            System.out.println("La pila esta llena");
        } else {
            top++;
            pila[top] = elemento;
            System.out.println("Elemento " + elemento + " insertado");
        }
    }

    // Operacion pop: eliminar el elemento superior de la pila
    public int pop() {
        if (top == -1) {
            System.out.println("La pila esta vacía");
            return -1; // Indicador de error
        } else {
            int elemento = pila[top];
            top--;
            System.out.println("Elemento " + elemento + " eliminado");
            return elemento;
        }
    }

    // Operacion peek: obtener el valor del elemento superior sin eliminarlo
    public int peek() {
        if (top == -1) {
            System.out.println("La pila esta vacía");
            return -1; // Indicador de error
        } else {
            return pila[top];
        }
    }

    // Operacion isEmpty: verificar si la pila esta vacia
    public boolean isEmpty() {
        return top == -1;
    }

    // Vaciar una Pila
    public void vaciarPila() {
        while (!isEmpty()) {
            pop();
        }
        System.out.println("La pila ha sido vaciada correctamente.");
    }

    // Contar Elementos
    public int contarElementos() {
        return top + 1;
    }

    //  Duplicar Elemento en la Cima
    public void duplicarCima() {
        if (isEmpty()) {
            System.out.println("No se puede duplicar, la pila esta vacía.");
        } else if (top == tamanoMaximo - 1) {
            System.out.println("No se puede duplicar, la pila esta llena.");
        } else {
            int cima = peek();
            push(cima);
            System.out.println("Elemento en la cima duplicado: " + cima);
        }
    }

    // Revertir los Elementos de una Pila
    public void revertirPila() {
        int[] temp = new int[top + 1];
        int i = 0;

        // Vaciar la pila al arreglo temporal
        while (!isEmpty()) {
            temp[i++] = pop();
        }

        // Volver a meterlos en orden inverso
        for (int j = 0; j < i; j++) {
            push(temp[j]);
        }

        System.out.println("La pila ha sido revertida.");
    }

    // Comparar Dos Pilas
    public static boolean compararPilas(Pila p1, Pila p2) {
        if (p1.contarElementos() != p2.contarElementos()) {
            return false;
        }

        for (int i = 0; i <= p1.top; i++) {
            if (p1.pila[i] != p2.pila[i]) {
                return false;
            }
        }

        return true;
    }

    // Metodo principal para probar las operaciones
    public static void main(String[] args) {
        Pila pila = new Pila(5); // Crear una pila  de 5

        pila.push(10);
        pila.push(20);
        pila.push(30);

        System.out.println("\nNumero de elementos en la pila: " + pila.contarElementos());
        System.out.println("Valor en la cima: " + pila.peek());

        pila.duplicarCima(); // Duplicar la cima
        System.out.println("Numero de elementos despues de duplicar: " + pila.contarElementos());

        pila.revertirPila(); // Revertir pila
        pila.vaciarPila();   // Vaciar pila

        // Comparar dos pilas
        Pila p1 = new Pila(3);
        Pila p2 = new Pila(3);
        p1.push(1);
        p1.push(2);
        p2.push(1);
        p2.push(2);

        System.out.println("\nLas pilas p1 y p2 son iguales?: " + Pila.compararPilas(p1, p2));
    }
}
