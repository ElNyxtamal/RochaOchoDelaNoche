package pila;

import java.util.Scanner; // <-- Necesitamos importar esto

public class CombinaPilaCola {

    private int[] datos;
    private int tamañoMaximo;
    private int topePila;
    private int frenteCola;
    private int finalCola;

    public CombinaPilaCola(int tamañoMaximo) {
        this.tamañoMaximo = tamañoMaximo;
        this.datos = new int[tamañoMaximo];
        this.topePila = -1;
        this.frenteCola = tamañoMaximo;
        this.finalCola = tamañoMaximo;
    }

    public boolean isPilaEmpty() {
        return topePila == -1;
    }

    public boolean isColaEmpty() {
        return frenteCola == finalCola;
    }

    public boolean isFull() {
        return (topePila + 1) == finalCola;
    }

    public void push(int elemento) {
        if (isFull()) {
            System.out.println("Error (Push): La estructura esta llena.");
        } else {
            topePila++;
            datos[topePila] = elemento;
            System.out.println("Push (Pila): " + elemento);
        }
    }

    public int pop() {
        if (isPilaEmpty()) {
            System.out.println("Error (Pop): La pila esta vacía.");
            return -1;
        } else {
            int elemento = datos[topePila];
            topePila--;
            System.out.println("Pop (Pila): " + elemento);
            return elemento;
        }
    }

    public void enqueue(int elemento) {
        if (isFull()) {
            System.out.println("Error (Enqueue): La estructura esta llena.");
        } else {
            finalCola--;
            datos[finalCola] = elemento;
            System.out.println("Enqueue (Cola): " + elemento);
        }
    }

    public int dequeue() {
        if (isColaEmpty()) {
            System.out.println("Error (Dequeue): La cola esta vacia.");
            return -1;
        } else {
            frenteCola--;
            int elemento = datos[frenteCola];
            System.out.println("Dequeue (Cola): " + elemento);
            return elemento;
        }
    }

    public void imprimirPila() {
        if (isPilaEmpty()) {
            System.out.println("Contenido Pila: (Vacía)");
            return;
        }
        System.out.print("Contenido Pila (Tope -> Base): ");
        for (int i = topePila; i >= 0; i--) {
            System.out.print(datos[i] + " ");
        }
        System.out.println();
    }

    public void imprimirCola() {
        if (isColaEmpty()) {
            System.out.println("Contenido Cola: (Vacia)");
            return;
        }
        System.out.print("Contenido Cola (Frente -> Final): ");
        for (int i = frenteCola - 1; i >= finalCola; i--) {
            System.out.print(datos[i] + " ");
        }
        System.out.println();
    }

    // --- NUEVO MÉTODO MAIN INTERACTIVO ---
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        CombinaPilaCola ds = new CombinaPilaCola(5); // Tamaño 5
        int opcion = 0;
        int valor;

        System.out.println("--- Estructura Pila/Cola Creada (Tamano 5) ---");

        // Insertamos los datos iniciales de la simulación
        System.out.println("--- Insertando elementos iniciales ---");
        ds.push(5);
        ds.push(10);
        ds.enqueue(15);
        ds.enqueue(20);
        
        ds.imprimirPila();
        ds.imprimirCola();

        // Bucle del menú
        while (opcion != 4) {
            System.out.println("\n--- Elige una operacion ---");
            System.out.println("1. Pop (SACAR de Pila)");
            System.out.println("2. Dequeue (SACAR de Cola)");
            System.out.println("3. Ver contenidos");
            System.out.println("4. Salir");
            System.out.print("Tu eleccion: ");

            opcion = scanner.nextInt();

            // Aquí es donde el usuario elige qué hacer
            switch (opcion) {
                case 1: // POP (ELECCIÓN DE SACAR DE PILA)
                    System.out.println("...Sacando de la PILA...");
                    ds.pop();
                    break;
                case 2: // DEQUEUE (ELECCIÓN DE SACAR DE COLA)
                    System.out.println("...Sacando de la COLA...");
                    ds.dequeue();
                    break;
                case 3: // VER
                    ds.imprimirPila();
                    ds.imprimirCola();
                    break;
                case 4:
                    System.out.println("Adios!");
                    break;
                default:
                    System.out.println("Opcion no valida. Intenta de nuevo.");
            }
        }
        
        scanner.close(); // Cerramos el scanner al salir
    }
}